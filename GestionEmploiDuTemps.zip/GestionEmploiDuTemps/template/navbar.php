<nav class="navbar navbar-expand-lg navbar-light bg-nav">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"><i class="fa fa-calendar" aria-hidden="true"></i> GESTION D'EMPLOI DU TEMPS</a>
  </div>
</nav>